﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Esercizio2temperature
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Istat istat;
        private static string _fileCsv = AppContext.BaseDirectory + @"file/dati.txt";
        public MainWindow()
        {
            InitializeComponent();

            istat = new Istat();
            istat.ImportaDatiDaFile(_fileCsv);
            lstComuni.ItemsSource = istat.Comuni;

        }

        private void btnTemeraturaMassima_Click(object sender, RoutedEventArgs e)
        {
            Object obj = lstComuni.SelectedItem;
            if(obj != null) { 
                Comune comune = obj as Comune;
                MessageBox.Show(""+comune.TemperaturaMassima());
            }
            else
            {
                MessageBox.Show("nessun comune selezionato");
            }
        }
    }
}
