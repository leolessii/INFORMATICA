﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Linq.Expressions;
using System.Security.Cryptography.Xml;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Shapes;

namespace Esercizio2temperature
{
    public class Istat
    {
        private List<Comune> _dati;

        public List<Comune> Comuni { get { return _dati; } }

        //leggere il file, creare i comuni e aggiungere ad ogni comune le temperature
        public void ImportaDatiDaFile(string percorsoFile)
        {
            _dati = new List<Comune>();
            //se trovate .... --> la temperatura non c'è non la salvo
            try
            {
                using (StreamReader sr = new StreamReader(percorsoFile))
                {
                    CultureInfo.CurrentCulture = new CultureInfo("en-US", false);
                    //perchè ha l'intestazione
                    string primaRiga;
                    primaRiga = sr.ReadLine();
                    string[] instestazione = primaRiga.Split(',');

                    string riga;
                    while((riga = sr.ReadLine()) != null)
                    {
                        string[]elementi = riga.Split(',');
                        Comune c = new Comune(elementi[0]);

                        List<Temperatura> temperature = new List<Temperatura>();
                        
                        for(int i =1; i<elementi.Length; i++)
                        {
                            if (elementi[i] != "....")
                            {
                                int anno = Convert.ToInt32(instestazione[i]);
                                double temp = Convert.ToDouble(elementi[i]);
                                Temperatura t = new Temperatura(anno, temp);
                                c.AggiungiTemperatura(t);
                            }
                        }
                        _dati.Add(c);
                    }
                }
            }
            catch (Exception ex)
            {

            }
        }

        public double? CercaTemperaturaMassimaComune(string nomeComune)
        {
            //cerca mella lista _dati un comune con il nome uguale a nomeComune
            foreach(Comune comune in _dati)
            {
                if (comune.Nome == nomeComune)
                {
                    //su quell'oggetto richiama il metodo TemperaturaMassima()
                    return comune.TemperaturaMassima();
                }
            }
            //se sono qui non è presente un comune con il nome che cerco
            return null;

        }

        //public List<Comune> ListaNomiComuniConTemperaturaInAnno(Temperatura temp)
        public List<string> ListaNomiComuniConTemperaturaInAnno(Temperatura temp)
        {
           // List<Comune> comuni = new List<Comune>();
            List<string> values = new List<string>();
            foreach (Comune comune in _dati)
            {
                if(comune.VerificaPresenzaTemperatura(temp))
                {
                    values.Add(comune.Nome);
                    //comuni.Add(comune);
                }
            }
            //return comuni;
            return values;
        }

        public double? TemperaturaMaggioreAnno(int anno)
        {
            double maxTemperaturaAnno = double.MinValue;
            foreach (Comune comune in _dati)
            {
                double? temp = comune.TemperaturaInAnno(anno);
                if (temp!=null && temp > maxTemperaturaAnno)
                {
                    maxTemperaturaAnno = (double)temp;
                }
            }
            //se questo è vero vuol dire che per quell'anno non ho nessuna temperatura registrata
            if(maxTemperaturaAnno == double.MinValue)
            {
                return null;
            }
            return maxTemperaturaAnno;
            
        }

    }
}
