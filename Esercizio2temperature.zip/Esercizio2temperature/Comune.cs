﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Esercizio2temperature
{
    public class Comune
    {
        private string _nome;
        private List<Temperatura> _temperature;

        public string Nome { get { return _nome; } }

        public Comune(string nome) 
        {
            _nome = nome;
            _temperature = new List<Temperatura>();
        }

        public void AggiungiTemperatura(Temperatura t)
        {
            //aggiungo l'oggetto temperatura alla lista
            _temperature.Add(t);
        }

        public double? TemperaturaMassima()
        {
            //se ci sono delle temperature
            if (_temperature.Count > 0)
            {
                //cerco il massimo valore tra le temperature e lo restituisco
                double tempMax = _temperature[0].Valore;
                foreach (Temperatura temperatura in _temperature)
                {
                    if (temperatura.Valore > tempMax)
                    {
                        tempMax = temperatura.Valore;
                    }
                }
                return tempMax;
            }
            return null;
        }

        public double? TemperaturaInAnno(int anno)
        {
            //ciclo su tutte le temperature
            foreach(Temperatura temperatura in _temperature)
            {
                //se ho una temperatura riferita all'anno di interesse la restituisco
                if(temperatura.Anno == anno)
                {
                    return temperatura.Valore;
                }
            }
            //se sono qui la temperatura dell'anno non esite nella mia lista
            return null;
        }

        public bool VerificaPresenzaTemperatura(Temperatura temperaturaDaTrovare)
        {            
            //ciclo su tutte le temperature del comune
            foreach(Temperatura temperatura in _temperature)
            {
                //verifico se c'è una temperatura uguale a quella che cerco (anno, valore)
                if(temperatura.Equals(temperaturaDaTrovare))
                    return true;
            }
            return false;
        }

        public override string ToString()
        {
            return Nome;
        }
    }
}
