﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Esercizio2temperature
{
    public class Temperatura
    {
        private int _anno;
        private double _valore;
        public int Anno { get { return _anno; } }
        public double Valore { get { return _valore;} }

        public Temperatura(int anno, double valore)
        {
            _anno = anno;
            _valore = valore;
        }

        //due temperature sono uguali se hanno lo stesso valore e si riferiscono allo stesso anno
        public override bool Equals(object? obj)
        {
            if(obj == null || !(obj is Temperatura)) return false;
            Temperatura tmp = (Temperatura)obj;
            if(tmp.Anno == _anno && tmp.Valore == _valore) return true;
            return false;
        }


    }
}
