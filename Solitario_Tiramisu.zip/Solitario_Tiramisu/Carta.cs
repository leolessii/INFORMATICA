﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Solitario_Tiramisu
{
    public enum Seme
    {
        denara,
        spade,
        coppe,
        bastoni
    }

    public enum Valore
    {
        asso = 1,
        due,
        tre,
        quattro,
        cinque,
        sei,
        sette,
        fante,
        cavallo,
        re
    }
    public class Carta
    {
        private Seme _semeCarta;
        private Valore _valoreCarta;

        public Seme SemeCarta
        {
            get { return _semeCarta; }

            private set
            {
                if (value < Seme.denara || value > Seme.bastoni) throw new ArgumentException("seme");
                _semeCarta = value ;
            }
        }

        public Valore ValoreCarta
        {
            get { return _valoreCarta; }

            private set
            {
                if (value < Valore.asso || value > Valore.re) throw new ArgumentException("valore");
            }
        }

        public Carta(Seme seme, Valore valore)
        {
            _valoreCarta = valore ;
            _semeCarta = seme;
        }

        public override bool Equals(object? obj)
        {
            if(obj != null && (obj as Carta).SemeCarta == SemeCarta) 
            {
                return true;
            }
            return false;
        }


    }
}
