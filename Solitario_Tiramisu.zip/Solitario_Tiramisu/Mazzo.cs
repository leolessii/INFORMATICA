﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Solitario_Tiramisu
{
    internal class Mazzo
    {
        private Carta[] _carte;

        public Carta[] Carte
        {
            get { return _carte; }

            private set
            {
                if (value.Length < 0) throw new ArgumentException("dimesione del mazzo errata");

                _carte = value;
            }
        }

        public Carta PescaCarta()
        {

        }

        public void MescolaMazzo()
        {

        }
    }
}
