﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace GamblingGame
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            btnStart.Visibility = Visibility.Collapsed;
        }

        private void btnStart_Click(object sender, RoutedEventArgs e)
        {
            string name = "";  

            if (name != null)
            name = txtNome.Text;

            int nFiches = 0;

            try
            {
                nFiches = Convert.ToInt32(txtNFiches.Text);
            }
            catch (System.FormatException)
            {
                txtFichesErrore.Text = "formato numero di fiches invalido";
            }
            

            if (nFiches <= 0
                
                )
            {
                lblTermini.Visibility = Visibility.Collapsed;
                check.Visibility = Visibility.Hidden;

                txtFichesErrore.Text = "non puoi giocare con 0 fiches o meno, correggi il valore";
            }
            else
            {
                lblTermini.Visibility = Visibility.Visible;
                check.Visibility = Visibility.Visible;
                txtFichesErrore.Visibility = Visibility.Collapsed;

                Giocatore g1 = new Giocatore(name, nFiches);

                GameWindow game = new GameWindow(g1);
                game.Show();
                this.Close();
            }

            
        }

        private void CheckBox_Checked(object sender, RoutedEventArgs e)
        {
            if(check.IsChecked == false) 
            {
                btnStart.Visibility = Visibility.Collapsed;
            }
            else
            {
                btnStart.Visibility = Visibility.Visible;
            }     
        }

    }
}
