﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GamblingGame
{
    public class Giocatore
    {
        private string _nome;
        private int _disponibilità;

        public Giocatore(string nome, int disponibilità)
        {
            Nome = nome;
            Disponibilità = disponibilità;
        }

        public int Disponibilità
        {
            get
            {
                return _disponibilità;
            }
            set
            {
                if (value <  0) 
                    throw new Exception("disponibilità non valida");
                else
                    _disponibilità = value;

            }
        }

        public string Nome
        {
            get { return _nome; }
            set
            {
                if(value == "" || value == null)
                    _nome = "Player1";                   
                else
                    _nome = value;
            }
        }

        public void Punta(int puntata)
        {
            Disponibilità -= puntata;
        }
    }
}
