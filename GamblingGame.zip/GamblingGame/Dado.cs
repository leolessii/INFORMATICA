﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GamblingGame
{
    public class Dado
    {
        public int LancioDado()
        {
            Random rnd = new Random();
            return rnd.Next(6) + 1;
        }
    }
}
