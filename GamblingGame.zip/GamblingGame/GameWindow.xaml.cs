﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.Pkcs;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace GamblingGame
{
    /// <summary>
    /// Logica di interazione per GameWindow.xaml
    /// </summary>
    public partial class GameWindow : Window
    {
        bool[] identificatori;
        Partita p1;
        Giocatore g1;
        int _disponibilitàIniziale;

        public bool[] Identificatore
        {
            get { return identificatori; }
        }

        int disponibilitàIniziale
        {
            get { return _disponibilitàIniziale; }
            set
            {
                if (value < 0) throw new ArgumentOutOfRangeException("value");
                _disponibilitàIniziale = value;
            }
        }

        public void InizializzaIdentificatori()
        {
            for (int i = 0; i < 10; i++)
            {
                identificatori[i] = false;
            }
        }

        public void NascondiTuttiIDadi()
        {
            dado1_1.Visibility = Visibility.Hidden;
            dado2_1.Visibility = Visibility.Hidden;
            dado3_1.Visibility = Visibility.Hidden;
            dado4_1.Visibility = Visibility.Hidden;
            dado5_1.Visibility = Visibility.Hidden;
            dado6_1.Visibility = Visibility.Hidden;
            dado1_2.Visibility = Visibility.Hidden;
            dado2_2.Visibility = Visibility.Hidden;
            dado3_2.Visibility = Visibility.Hidden;
            dado4_2.Visibility = Visibility.Hidden;
            dado5_2.Visibility = Visibility.Hidden;
            dado6_2.Visibility = Visibility.Hidden;
            dado1_3.Visibility = Visibility.Hidden;
            dado2_3.Visibility = Visibility.Hidden;
            dado3_3.Visibility = Visibility.Hidden;
            dado4_3.Visibility = Visibility.Hidden;
            dado5_3.Visibility = Visibility.Hidden;
            dado6_3.Visibility = Visibility.Hidden;
        }

        private void NascondiScommesse()
        {
            btnBig.Visibility = Visibility.Collapsed;
            btnSmall.Visibility = Visibility.Collapsed;
            btnPari.Visibility = Visibility.Collapsed;
            btnDispari.Visibility = Visibility.Collapsed;
            btnTriplaGenerica.Visibility = Visibility.Collapsed;
            btnTriplaSpecifica.Visibility = Visibility.Collapsed;
            btnDoppia.Visibility = Visibility.Collapsed;
            btnTotale.Visibility = Visibility.Collapsed;
            btnDadoSingolo.Visibility = Visibility.Collapsed;
            btnCombinazione.Visibility = Visibility.Collapsed;
        }

        private void FaiComparireScommesse()
        {
            btnBig.Visibility = Visibility.Visible;
            btnSmall.Visibility = Visibility.Visible;
            btnPari.Visibility = Visibility.Visible;
            btnDispari.Visibility = Visibility.Visible;
            btnTriplaGenerica.Visibility = Visibility.Visible;
            btnTriplaSpecifica.Visibility = Visibility.Visible;
            btnDoppia.Visibility = Visibility.Visible;
            btnTotale.Visibility = Visibility.Visible;
            btnDadoSingolo.Visibility = Visibility.Visible;
            btnCombinazione.Visibility = Visibility.Visible;
        }

        public GameWindow(Giocatore gX)
        {
            g1 = (Giocatore)gX;
            p1 = new Partita(g1);
            disponibilitàIniziale = g1.Disponibilità;

            InitializeComponent();
            txtNomePlayer.Text = g1.Nome;
            txtNFiches.Text = g1.Disponibilità.ToString();

            identificatori = new bool[10];
            InizializzaIdentificatori();
            NascondiTuttiIDadi();
            NascondiScommesse();
            btnLancia.Visibility = Visibility.Collapsed;
        }
        private void AggiornaPuntata()
        {
            try
            {
                p1.PuntataAttuale = int.Parse(txtNFichesPuntate.Text);
            }
            catch (Exception ex)
            {
                txtErrore.Text = ex.Message;
            }
        }

        private void btnBig_Click(object sender, RoutedEventArgs e)
        {
            AggiornaPuntata();
            p1.SceltaScommessa(0,0,0);
            btnLancia.Visibility= Visibility.Visible;
        }

        private void btnSmall_Click(object sender, RoutedEventArgs e)
        {
            AggiornaPuntata();
            p1.SceltaScommessa(1, 0, 0);
            btnLancia.Visibility = Visibility.Visible;
        }

        private void btnPari_Click(object sender, RoutedEventArgs e)
        {
            AggiornaPuntata();
            p1.SceltaScommessa(2, 0, 0);
            btnLancia.Visibility = Visibility.Visible;
        }

        private void btnDispari_Click(object sender, RoutedEventArgs e)
        {
            AggiornaPuntata();
            p1.SceltaScommessa(3, 0, 0);
            btnLancia.Visibility = Visibility.Visible;
        }

        private void btnTriplaGenerica_Click(object sender, RoutedEventArgs e)
        {
            AggiornaPuntata();
            p1.SceltaScommessa(4,0,0);
            btnLancia.Visibility = Visibility.Visible;
        }

        private void btnTriplaSpecifica_Click(object sender, RoutedEventArgs e)
        {            
            if (txtValueTS.Text != "" && txtValueTS.Text != null)
            {
                string vlaueTSString = txtValueTS.Text;
                int valueTS = Convert.ToInt32(vlaueTSString);

                if (valueTS > 0 || valueTS < 7)
                {
                    AggiornaPuntata();
                    p1.SceltaScommessa(5, valueTS, 0);
                    btnLancia.Visibility = Visibility.Visible;
                }
            }
        }

        private void btnDoppia_Click(object sender, RoutedEventArgs e)
        {
            if (txtValueD.Text != "" && txtValueD.Text != null)
            {
                string vlaueDString = txtValueD.Text;
                int valueTS = Convert.ToInt32(vlaueDString);

                if (valueTS > 0 || valueTS < 7)
                {
                    AggiornaPuntata();
                    p1.SceltaScommessa(6, valueTS, 0);
                    btnLancia.Visibility = Visibility.Visible;
                }
            }
        }

        private void btnTotale_Click(object sender, RoutedEventArgs e)
        {
            
            if (txtValueT.Text != "" && txtValueT.Text != null)
            {
                string vlaueTString = txtValueT.Text;
                int valueTS = Convert.ToInt32(vlaueTString);

                if (valueTS > 3 || valueTS < 18)
                {
                    AggiornaPuntata();
                    p1.SceltaScommessa(7, valueTS, 0);
                    btnLancia.Visibility = Visibility.Visible;
                }
            }


        }

        private void btnDadoSingolo_Click(object sender, RoutedEventArgs e)
        {
            AggiornaPuntata();
            if (txtValueDSingle.Text != "" && txtValueDSingle.Text != null)
            {
                string valueDSString = txtValueDSingle.Text;
                int valueTS = Convert.ToInt32(valueDSString);

                if (valueTS > 0 || valueTS < 7)
                {
                    AggiornaPuntata();
                    p1.SceltaScommessa(8, valueTS, 0);
                    btnLancia.Visibility = Visibility.Visible;
                }
            }

        }

        private void btnCombinazione_Click(object sender, RoutedEventArgs e)
        {
            
            if (txtValueComb1.Text != "" && txtValueComb1.Text != null && txtValueComb2.Text != "" && txtValueComb2.Text != null)
            {
                string valueComb1String = txtValueComb1.Text;
                string valueComb2String = txtValueComb2.Text;
                int valueComb1 = Convert.ToInt32(valueComb1String);
                int valueComb2 = Convert.ToInt32(valueComb2String);

                if (valueComb1 > 0 && valueComb2 < 7 && valueComb2 > 0 && valueComb2 < 7)
                {
                    AggiornaPuntata();
                    p1.SceltaScommessa(9, valueComb1, valueComb2);
                    btnLancia.Visibility = Visibility.Visible;
                }
            }
        }

        public void ControllaDadoVisibile()
        {
            int nd1 = p1.Dado1;
            if(nd1 == 1) { dado1_1.Visibility = Visibility.Visible; }
            else if (nd1 == 2) { dado2_1.Visibility = Visibility.Visible; }
            else if (nd1 == 3) { dado3_1.Visibility = Visibility.Visible; }
            else if (nd1 == 4) { dado4_1.Visibility = Visibility.Visible; }
            else if (nd1 == 5) { dado5_1.Visibility = Visibility.Visible; }
            else if (nd1 == 6) { dado6_1.Visibility = Visibility.Visible; }
            int nd2 = p1.Dado2;
            if (nd2 == 1) { dado1_2.Visibility = Visibility.Visible; }
            else if (nd2 == 2) { dado2_2.Visibility = Visibility.Visible; }
            else if (nd2 == 3) { dado3_2.Visibility = Visibility.Visible; }
            else if (nd2 == 4) { dado4_2.Visibility = Visibility.Visible; }
            else if (nd2 == 5) { dado5_2.Visibility = Visibility.Visible; }
            else if (nd2 == 6) { dado6_2.Visibility = Visibility.Visible; }
            int nd3 = p1.Dado3;
            if (nd3 == 1) { dado1_3.Visibility = Visibility.Visible; }
            else if (nd3 == 2) { dado2_3.Visibility = Visibility.Visible; }
            else if (nd3 == 3) { dado3_3.Visibility = Visibility.Visible; }
            else if (nd3 == 4) { dado4_3.Visibility = Visibility.Visible; }
            else if (nd3 == 5) { dado5_3.Visibility = Visibility.Visible; }
            else if (nd3 == 6) { dado6_3.Visibility = Visibility.Visible; }
        }

        private void btnLancia_Click(object sender, RoutedEventArgs e)
        {

            p1.LancioDadi();
            ControllaDadoVisibile();
            int vittoria = p1.GestioneVittoria();
            MessageBox.Show($"hai vinte {vittoria} fiches");
            NascondiTuttiIDadi();
            p1.InizializzaTurno();
            txtNFiches.Text = p1.Giocatore1.Disponibilità.ToString();
            btnLancia.Visibility = Visibility.Collapsed;
            txtErrore.Text = "";

            if (g1.Disponibilità == 0)
            {
                btnStop_Click(sender, e);
            }     
        }

        private void btnStop_Click(object sender, RoutedEventArgs e)
        {
            int fichesVinte = g1.Disponibilità - disponibilitàIniziale;
            if (fichesVinte < 0) { fichesVinte = 0; }
            FinalWindow game = new FinalWindow(g1, fichesVinte);
            game.Show();
            this.Close();
        }

        private void txtNFichesPuntate_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (txtNFichesPuntate.Text == null || txtNFichesPuntate.Text == "")
            {
                NascondiScommesse();
            }
            else
            {
                FaiComparireScommesse();
            }
        }
    }
}
