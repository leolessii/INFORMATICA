﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GamblingGame
{
    public class Partita
    {
        Giocatore _giocatore;
        Dado _dado;
        public int _puntataAttuale;
        public int _d1, _d2, _d3;
        private bool[] _scommessa = new bool[10];
        private int[] _pagamento = { 2, 2, 2, 2, 30, 150, 8, 2, 2, 5 };  //array contenente le quote da pagare in caso di vincita
        private int _totaleVincita;
        private int _totaleScommessa;
        private int[] _valoriGiocati = new int[6];


        public Partita(Giocatore g1)
        {
            _giocatore = g1;
            _dado = new Dado();
            
        }

        public Giocatore Giocatore1
        {
            get
            {
                return _giocatore;
            }
        }

        public void InizializzaTurno()
        {
            _puntataAttuale = 0;
            _totaleScommessa = 0;
            _totaleVincita = 0;

            for(int i = 0; i < _valoriGiocati.Length; i++)
            {
                _valoriGiocati[i] = 0;
            } 
            for(int i = 0; i < _scommessa.Length; i++)
            {
                _scommessa[i] = false;
            }
        }

        public int PuntataAttuale
        {
            get { return _puntataAttuale; }

            set
            {
                if (value > _giocatore.Disponibilità )
                {
                    throw new Exception("non puoi puntare più delle fiches che possiedi");
                }
                else if(value < 0)
                {
                    throw new Exception("non puoi scommettere un numero negativo di fiches");
                }
                else
                {
                    _puntataAttuale = value;
                }
            }
        }

        public int Dado1
        {
            get { return _d1; }
        }
        public int Dado2
        {
            get { return _d2; }
        }
        public int Dado3
        {
            get { return _d3; }
        }

        public void LancioDadi()
        {
            _d1 = _dado.LancioDado();
            _d2 = _dado.LancioDado();
            _d3 = _dado.LancioDado();
        }

        private int Somma()
        {
            return _d1 + _d2 + _d3;
        }

        private bool Big()
        {
            if (!TriplaGenerica())
            {
                if (Somma() >= 11 && Somma() <= 17)
                {
                    return true;
                }
            }

            return false;
        }

        private bool Small()
        {
            if (!TriplaGenerica())
            {
                if (Somma() >= 4 && Somma() <= 10)
                {
                    return true;
                }
            }

            return false;
        }

        private bool Pari()
        {
            if (!TriplaGenerica())
            {
                if (Somma() % 2 == 0)
                {
                    return true;
                }
            }

            return false;
        }

        private bool Dispari()
        {
            if (!TriplaGenerica())
            {
                if (!Pari())
                {
                    return true;
                }
            }

            return false;
        }

        private bool TriplaGenerica()
        {
            if (_d1 == _d2 && _d1 == _d3)
            {
                return true;
            }

            return false;
        }

        private bool TriplaSpecifica()
        {
            if (TriplaGenerica() && _d1 == _valoriGiocati[0])
            {
                return true;
            }

            return false;
        }

        private bool Doppia()
        {
            if (_d1 == _d2 && _d1 == _valoriGiocati[1])
            {
                return true;
            }
            if (_d1 == _d3 && _d1 == _valoriGiocati[1])
            {
                return true;
            }
            if (_d2 == _d3 && _d2 == _valoriGiocati[1])
            {
                return true;
            }

            return false;
        }

        private bool Totale()
        {
            if (_valoriGiocati[2] <= 3 || _valoriGiocati[2] == 18) throw new ArgumentException("non puoi scommettere sui numeri minori di 4 o sul 18");

            if (Somma() == _valoriGiocati[2])
            {
                return true;
            }

            return false;
        }        

        private bool DadoSingolo()
        {
            if (_d1 == _valoriGiocati[3] || _d2 == _valoriGiocati[3] || _d3 == _valoriGiocati[3])
            {
                return true;
            }

            return false;
        }        

        private bool Combinazione()
        {
            if (_valoriGiocati[4] == _valoriGiocati[5])
            {
                if (_d1 == _valoriGiocati[4] && (_d2 == _valoriGiocati[5] || _d3 == _valoriGiocati[5]))
                {
                    return true;
                }

                if (_d2 == _valoriGiocati[4] && (_d1 == _valoriGiocati[5] || _d3 == _valoriGiocati[5]))
                {
                    return true;
                }

                if (_d3 == _valoriGiocati[4] && (_d2 == _valoriGiocati[5] || _d1 == _valoriGiocati[5]))
                {
                    return true;
                }
            }
            else
            {
                if ((_d1 == _valoriGiocati[4] || _d2 == _valoriGiocati[4] || _d3 == _valoriGiocati[4]) && (_d1 == _valoriGiocati[5] || _d2 == _valoriGiocati[5] || _d3 == _valoriGiocati[5]))
                {
                    return true;
                }
            }

            return false;
        }

        private void AggiornamentoArrayScommesse()
        {

            if (_scommessa[0])
            {
                _scommessa[0] = Big();
            }

            if (_scommessa[1])
            {
                _scommessa[1] = Small();
            }

            if (_scommessa[2])
            {
                _scommessa[2] = Pari();
            }

            if (_scommessa[3])
            {
                _scommessa[3] = Dispari();
            }

            if (_scommessa[4])
            {
                _scommessa[4] = TriplaGenerica();
            }

            if (_scommessa[5])
            {
                _scommessa[5] = TriplaSpecifica();
            }

            if (_scommessa[6])
            {
                _scommessa[6] = Doppia();
            }

            if (_scommessa[7])
            {
                _scommessa[7] = Totale();
            }

            if (_scommessa[8])
            {
                _scommessa[8] = DadoSingolo();
            }

            if (_scommessa[9])
            {
                _scommessa[9] = Combinazione();
            }
        }

        public void SceltaScommessa(int scelta, int val1, int val2)
        {
            _giocatore.Punta(_puntataAttuale);
            _scommessa[scelta] = true;
            _totaleScommessa += _puntataAttuale;

            int j = 0;

            for (int i = 5; i < _scommessa.Length; i++)
            {
                if (_scommessa[i] == true && i != 9)
                {
                    _valoriGiocati[j] = val1;
                }
                else
                {
                    _valoriGiocati[j] = val1;
                    _valoriGiocati[j + 1] = val2;
                }

                j++;
            }
        }

        public int GestioneVittoria()
        {
            AggiornamentoArrayScommesse();

            for (int i = 0; i < _scommessa.Length; i++)
            {
                if (_scommessa[i])
                    _totaleVincita += _puntataAttuale * _pagamento[i];
            }

            _giocatore.Disponibilità += _totaleVincita;           
            return _totaleVincita;
        }
    }
}
