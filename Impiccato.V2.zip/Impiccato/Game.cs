﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Impiccato
{
    internal class Game
    {
        private Player _player;
        private string _word;
        private List<string> _wordsList;
        private static string _percorsoFile = @"";      //inserisci il percorso file
        private List<char> _lettereInserite;
        private List<char> _segniParola;

        public Player Player
        { 
            get { return _player; }
            set 
            {
                if (_player == null) throw new ArgumentNullException("Player");
                _player = value; 
            }
        }

        public string Word
        {
            get { return _word; }
            set
            {
                if (value == null || value == "") throw new ArgumentException("Word");
                _word = value;
            }
        }

        public List<string> WordsList
        {
            get { return _wordsList; }
        }

        public List<char> LettereInserite
        {
            get { return _lettereInserite; }
        }

        public List<char> SegniParola
        {
            get { return _segniParola; }
        }

        public Game(Player p)
        {
            Player = p;
            _wordsList = new List<string>();
            RiempimentoLista();
            Word = EstraiParola();                                                       
        }

        public void RiempimentoLista()
        {
            int counter = 0;
            try
            {
                using(StreamReader sr = new StreamReader(_percorsoFile))
                {
                    string line;
                    while((line = sr.ReadLine()) != null)
                    {
                        WordsList.Add(line);
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }

        public string EstraiParola()
        {
            Random rnd = new Random();
            int indice=rnd.Next(WordsList.Capacity);

            string wordToGuess = WordsList[indice];
            return wordToGuess;
        }

        public void GuessLetter(char letter)
        {
            bool presence= false;

            if(_lettereInserite.Contains(letter))
            {
                Player.SubLife();
            }
            else
            {
                foreach (Char ch in Word)
                {
                    if (char.ToLower(letter) == char.ToLower(ch))
                    {
                        presence = true;
                    }
                }
                if (presence == false)
                {
                    Player.SubLife();
                }
            }
            LettereInserite.Add(letter);
        }

        public bool GuessTheWord(string guess)
        {
            bool win=false;

            if(guess == Word)
            {
                win = true;
            }
            else if (guess != Word)
            {
                Player.SubLife();
                win = false;
            }

            return win;
        }

    }
}
