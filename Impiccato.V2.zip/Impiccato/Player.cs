﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Impiccato
{
    public class Player
    {
        private string _name;
        private int _lifes;

        public string Name
        {
            get { return _name; }
            set 
            {
                if(value == null || value == "") throw new ArgumentException("Name");
                _name = value;
            }
        }

        public int Lifes
        {
            get { return _lifes; }
            private set
                    {
                        if (value <= 0) throw new ArgumentException("Lifes");
                        _lifes = value;
                    }
        }

        public Player(string name)
        {
            Name = name;
            Lifes = 11;
        }

        public int SubLife()
        {
            _lifes--;
            return _lifes;
        }
    }
}
