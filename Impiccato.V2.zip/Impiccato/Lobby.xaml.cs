﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Impiccato
{
    /// <summary>
    /// Logica di interazione per Lobby.xaml
    /// </summary>
    public partial class Lobby : Window
    {
        Player player;
        public Lobby()
        {
            InitializeComponent();
            player.Name=txtName.Text;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            MainWindow game = new MainWindow(player);
            game.Show();
            this.Close();
        }
    }
}
