﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Impiccato
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Game hangedGame;

        public MainWindow(Player p)
        {
            InitializeComponent();
            HideAllImage();
            hangedGame= new Game(p);
        }

        public void HideAllImage()
        {
            imgImp1.Visibility = Visibility.Hidden;
            imgImp2.Visibility = Visibility.Hidden;
            imgImp3.Visibility = Visibility.Hidden;
            imgImp4.Visibility = Visibility.Hidden;
            imgImp5.Visibility = Visibility.Hidden;
            imgImp6.Visibility = Visibility.Hidden;
            imgImp7.Visibility = Visibility.Hidden;
            imgImp8.Visibility = Visibility.Hidden;
            imgImp9.Visibility = Visibility.Hidden;
            imgImp10.Visibility = Visibility.Hidden;
            imgImp11.Visibility = Visibility.Hidden;
        }

        public void ShowAllImage()
        {
            imgImp1.Visibility = Visibility.Visible;
            imgImp2.Visibility = Visibility.Visible;
            imgImp3.Visibility = Visibility.Visible;
            imgImp4.Visibility = Visibility.Visible;
            imgImp5.Visibility = Visibility.Visible;
            imgImp6.Visibility = Visibility.Visible;
            imgImp7.Visibility = Visibility.Visible;
            imgImp8.Visibility = Visibility.Visible;
            imgImp9.Visibility = Visibility.Visible;
            imgImp10.Visibility = Visibility.Visible;
            imgImp11.Visibility = Visibility.Visible;
        }

    }
}
