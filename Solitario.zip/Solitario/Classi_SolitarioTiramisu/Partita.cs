﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Classi_SolitarioTiramisu
{
    internal class Partita
    {
        private Mazzo mazzo;

        private Mazzetto[] _tavolo;
        private Mazzetto[] _mano;
        private Giocatore _giocatore;

        public Partita(string nome)
        {
            mazzo = new Mazzo();
            _tavolo = new Mazzetto[4];
            _mano = new Mazzetto[4];
            _giocatore = new Giocatore(nome);
        }

        public Carta PescaDalMazzo()
        {

        }

        public void SpostaCartaMano(int mazzettoPrecedente, int mazzettoDestinazione)
        {

        }


        public void SpostaCartaDaManoATavolo(int mazzettoPrecedente, int mazzettoDestinazione)
        {

        }

        private void TerminaPartita()
        {

        }

        private bool SuccessioneCarta(Carta carta)
        {

        }

    }
}
