﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Classi_SolitarioTiramisu
{
    internal class Mazzo
    {
        private Carta[] _carte;
        private bool _mazzoTerminato;

        public Mazzo()
        {
            InizializzaMazzo();

            _mazzoTerminato = false;
        }
        public Carta[] Carte
        {
            get { return _carte; }

            private set
            {
                if (value.Length < 0) throw new ArgumentException("dimesione del mazzo errata");

                _carte = value;
            }
        }

        public bool MazzoTerminato
        {
            get { return _mazzoTerminato; }
        }

        public Carta PescaCarta()
        {
            for (int i = 0; i < _carte.Length; i++)
            {
                if (_carte[i] != null)
                {
                    return _carte[i];
                }
            }

            _mazzoTerminato = true;

            return null;
        }


        private void InizializzaMazzo()
        {
            int i = 0;
            for (int seme = 1; seme <= 4; seme++)
            {
                for (int valore = 1; valore <= 10; valore++)
                {
                    _carte[i] = new Carta((Seme)seme, (Valore)valore);
                    i++;
                }
            }
        }

        public void MescolaMazzo()
        {
            Random random = new Random();
            int pos;
            Carta cartaDaScambiare;
            for (int j = 0; j < 1000; j++)
            {
                for (int i = 0; i < _carte.Length; i++)
                {
                    pos = random.Next(0, _carte.Length);
                    cartaDaScambiare = _carte[pos];
                    _carte[pos] = _carte[i];
                    _carte[i] = cartaDaScambiare;
                }
            }
        }

        public void RigeneraMazzo()
        {

        }

        public override bool Equals(object? obj)
        {
            return base.Equals(obj);
        }

    }
}
