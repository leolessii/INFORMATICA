﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Classi_SolitarioTiramisu
{
    internal class Mazzetto
    {
        //private List<Carta> _carte;
        private Carta[] _carta;

        public Mazzetto()
        {
            //_carte = new List<Carta>();
        }

        public Carta[] Carta
        {
            get 
            { 
                return _carta; 
            }


        }

        public void AggiungiCarta(Carta carta)
        {
            //_carte.Add(carta);
        }

        public void RimuoviCarta()
        {
            //_carte.Remove(_carte[_carte.Count - 1]);
        }
    }
}

// modifcare facendo array-lista