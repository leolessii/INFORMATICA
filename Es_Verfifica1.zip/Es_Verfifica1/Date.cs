﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Design;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Es_Verfifica1
{
    internal class Date
    {
        private static string _file = AppContext.BaseDirectory + @"file/dates.txt";
        private static string _fileOutput = AppContext.BaseDirectory + @"file/dates_Output.txt";
        public List<string> dates;

        public Date() 
        {
            dates = new List<string>();
            ReadFile();
            RecomposeList();
            WriteOutput();
        }

        private List<string> ReadFile()
        {
            using (StreamReader sr = new StreamReader(_file))
            {
                while (!sr.EndOfStream)
                {
                    dates.Add(sr.ReadLine());
                }
            }
            return dates;
        }

        private void RecomposeList()
        {
            for(int i=0; i<dates.Capacity; i++)
            {
                dates[i] = CorrectString(dates[i]);
            }
        }

        private string CorrectString(string str)
        {
            string correctDate = "";
            int num = 0;

            string[] dateString = str.Split('/', '-');

            //01 o 1 o 21 o 111 o oii riguardare i controlli e mettere i try e catch
            if (dateString[0].Length == 1) { dateString[0] = $"0{dateString[0]}/"; };
            if (dateString[0].Length == 2) { dateString[0] = $"{dateString[0]}/"; };
            correctDate += dateString[0];
       
            if (dateString[1].Length == 1) { dateString[1] = $"0{dateString[1]}/"; };
            if (dateString[1].Length == 2) { dateString[1] = $"{dateString[1]}/"; };
            correctDate += dateString[1];

            if (dateString[2].Length == 2) { dateString[2] = $"19{dateString[2]}"; };
            correctDate += dateString[2];

            return correctDate;
        }

        private void WriteOutput()
        {
            using (StreamWriter sw = new StreamWriter(_fileOutput))
            {
                for (int i = 0; i < dates.Capacity; i++)
                {
                    sw.Write(dates[i]);
                }
            }
        }
    }
}
