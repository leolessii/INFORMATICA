﻿namespace Es_Verfifica1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Date date = new Date();
            for(int i = 0; i < date.dates.Capacity; i++) 
            {
                Console.WriteLine(date.dates[i]);
            }
        }
    }
}