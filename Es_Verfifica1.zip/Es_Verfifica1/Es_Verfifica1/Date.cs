﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Design;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Es_Verfifica1
{
    internal class Date
    {
        private static string _file = AppContext.BaseDirectory + @"file/dates.txt";
        private static string _fileOutput = AppContext.BaseDirectory + @"file/dates_Output.txt";
        private static string _fileCsv = AppContext.BaseDirectory + @"file/dates.csv";
        private static string _fileCsvOutput = AppContext.BaseDirectory + @"file/dates_Output.csv";
        public List<DateTime> dates;

        public Date(int scelta) 
        {
            dates = new List<DateTime>();
            if(scelta==1)
            {
                ReadAndCorrectFile();
                WriteOutput();
            }
            else if(scelta==2)
            {

            }
        }

        private void ReadAndCorrectFile()
        {
            using (StreamReader sr = new StreamReader(_file))
            {
                while (!sr.EndOfStream)
                {
                    CorrectString(sr.ReadLine());
                }
            }
        }

        private string CorrectString(string str)
        {
            string correctDate = "";
            int num = 0;
            int a = 0;
            int m = 0;
            int g = 0;

            string[] dateString = str.Split('/', '-');

            //01 o 1 o 21 o 111 o oii riguardare i controlli e mettere i try e catch
            if (dateString[0].Length == 1) { dateString[0] = $"0{dateString[0]}/"; };
            if (dateString[0].Length == 2) { dateString[0] = $"{dateString[0]}/"; };
            g = Convert.ToInt32(dateString[0]);
            correctDate += dateString[0];
       
            if (dateString[1].Length == 1) { dateString[1] = $"0{dateString[1]}/"; };
            if (dateString[1].Length == 2) { dateString[1] = $"{dateString[1]}/"; };
            m = Convert.ToInt32(dateString[0]);
            correctDate += dateString[1];

            if (dateString[2].Length == 2) { dateString[2] = $"19{dateString[2]}"; };
            a = Convert.ToInt32(dateString[0]);
            correctDate += dateString[2];

            FillTheList(a, m, g);

            return correctDate;
        }

        public void FillTheList(int a, int m, int g)
        {
            dates.Add(new DateTime(a, m, g));
        }

        private void WriteOutput()
        {
            using (StreamWriter sw = new StreamWriter(_fileOutput))
            {
                for (int i = 0; i < dates.Capacity; i++)
                {
                    sw.Write(dates[i]);
                }
            }
        }
    }
}
